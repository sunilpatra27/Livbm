const express = require('express');
const app = express();
const cors = require('cors');
const user = require('../models/user');
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
var passwordHash = require('password-hash');

app.post('/saveUser', function(req, res) {


    var userDetails = req.body;
    var hashedPassword = passwordHash.generate(userDetails.password);   
    userDetails.password= hashedPassword;
    
    user.saveUser(userDetails, (err, data) => {
        if (err) {
            console.log('Error while connecting to server');
            res.json({ success: false, msg: 'Error While adding the usre ! Contact Support!' });
        } else {
          
            console.log(data);
            res.json({ success: true, msg: 'Add user successful!', users: data });
        }
    })
})
app.post('/checkUserName', function(req, res) {


    var userDetails = req.body;
    
    
    user.checkUserName(userDetails, (err, data) => {
        if (err) {
            console.log('Error while connecting to server');
            res.json({ success: false, msg: 'Error getting user! Contact Support!' });
        } else {
          
            console.log(data);
            res.json({ success: true, msg: 'username check', users: data });
        }
    })
})

app.post('/checkEmail', function(req, res) {


    var userDetails = req.body;
    
    
    user.checkEmail(userDetails, (err, data) => {
        if (err) {
            console.log('Error while connecting to server');
            res.json({ success: false, msg: 'Error getting user! Contact Support!' });
        } else {
          
            console.log(data);
            res.json({ success: true, msg: 'username check', users: data });
        }
    })
})
module.exports = app;

