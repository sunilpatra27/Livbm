import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import {LibService} from '../services/lib.service';
import { HttpClient,HttpErrorResponse} from '@angular/common/http';
import {NgSelectModule,NgOption} from '@ng-select/ng-select';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  registerForm: FormGroup;
    submitted = false;
    userJson:any={};
    countries;
    skills;
  
    constructor(private formBuilder: FormBuilder,private libService:LibService,private http:HttpClient ) { }

    ngOnInit() {
      
        this.registerForm = this.formBuilder.group({
          userName: ['', Validators.required],
          email: ['', [Validators.required, Validators.email]],
            firstName: ['', Validators.required],
            lastName: ['', Validators.required],
            dob: ['', [Validators.required]],
            password: ['', [Validators.required, Validators.minLength(6)]],
            skils:['',[Validators.required]],
            country:['',[Validators.required]]
        });

        this.http.get('../../assets/Json/country.json').subscribe(
          data=>{
            this.countries=data;
            console.log(this.countries);
          },
          (err:HttpErrorResponse)=>{
            console.log(err.message);
          }
        )
        this.http.get('../../assets/Json/skills.json').subscribe(
          data=>{
            this.skills=data;
            console.log(this.skills);
          },
          (err:HttpErrorResponse)=>{
            console.log(err.message);
          }
        )
    }

    // convenience getter for easy access to form fields
    get f() { return this.registerForm.controls; }

    onSubmit() {
        this.submitted = true;


        // stop here if form is invalid
        if (this.registerForm.invalid) {
            return;
        }
        else{


          this.userJson.userName=this.registerForm.controls.userName.value;
          this.userJson.email=this.registerForm.controls.email.value;
          this.userJson.firstName=this.registerForm.controls.firstName.value;
          this.userJson.lastName=this.registerForm.controls.lastName.value;
          this.userJson.dob=this.registerForm.controls.dob.value;
          this.userJson.password=this.registerForm.controls.password.value;
          this.userJson.skils=this.registerForm.controls.skils.value;
          this.userJson.country=this.registerForm.controls.country.value;
          this.userJson.database="user_db";

        this.libService.signup(JSON.stringify(this.userJson))
        .subscribe(data => {
              
console.log("data",data);


Swal.fire({ text: 'User Registerd successfully.', type: 'success', confirmButtonText: 'Ok' });
this.registerForm.reset();
this.submitted=false;

            },

            (err: HttpErrorResponse) => {
if (err.status == 408) {
Swal.fire({ text: err.error, type: 'warning', confirmButtonText: 'Ok' })
      
  } else if (err.status == 403) {
  Swal.fire({ text: err.error, type: 'warning', confirmButtonText: 'Ok' })
      
  } else{
  Swal.fire({ text: 'Something Went Wrong.', type: 'warning', confirmButtonText: 'Ok' })
  }
            });

    }

}


checkUserName(){
  let userDetails:any={};
  userDetails.userName=this.registerForm.controls.userName.value;
  userDetails.database="user_db";
  this.libService.checkUserName(JSON.stringify(userDetails))
        .subscribe(data => {
              
console.log("data",data);

if(data['users']){
    Swal.fire({ text: "Same user name exist plz try a diffrent one ! ", type: 'warning', confirmButtonText: 'Ok' })
    this.registerForm.patchValue({userName:""});
}


            },

            (err: HttpErrorResponse) => {
if (err.status == 408) {
Swal.fire({ text: err.error, type: 'warning', confirmButtonText: 'Ok' })
      
  } else if (err.status == 403) {
  Swal.fire({ text: err.error, type: 'warning', confirmButtonText: 'Ok' })
      
  } else{
  Swal.fire({ text: 'Something Went Wrong.', type: 'warning', confirmButtonText: 'Ok' })
  }
            });

    }


    checkEmail(){
      let userDetails:any={};
  userDetails.email=this.registerForm.controls.email.value;
  userDetails.database="user_db";
      this.libService.checkEmail(JSON.stringify(userDetails))
            .subscribe(data => {
                  
    console.log("data",data);
    
    if(data['users']){
      Swal.fire({ text: "Same user name exist plz try a diffrent one ! ", type: 'warning', confirmButtonText: 'Ok' })
      
      this.registerForm.patchValue({email:""});
  }
    
    
                },
    
                (err: HttpErrorResponse) => {
    if (err.status == 408) {
      Swal.fire({ text: err.error, type: 'warning', confirmButtonText: 'Ok' })
          
      } else if (err.status == 403) {
       Swal.fire({ text: err.error, type: 'warning', confirmButtonText: 'Ok' })
          
      } else{
      Swal.fire({ text: 'Something Went Wrong.', type: 'warning', confirmButtonText: 'Ok' })
      }
                });
    
        }
  
}





