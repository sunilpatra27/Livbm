const express = require('express');
const app = express();
const cors = require('cors');
const login = require('../models/login');
var bodyParser = require('body-parser');
var passwordHash = require('password-hash');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


app.post('/login', function(req, res) {

    console.log("mapped");


    var loginDetails = req.body;
   
    login.login(loginDetails, (err, data) => {
        if (err) {
          
            res.json({ success: false, msg: 'Error getting userid ! Contact Support!' });
        } else {
            console.log('login success');
           
            if(passwordHash.verify(loginDetails.password, data[0].password)){
                 res.json({ success: true, msg: 'Login Success!'});
            }
            else{

                res.json({ success: true, msg: 'Login failed!'});
            }
           
        }
    })
})













module.exports = app;