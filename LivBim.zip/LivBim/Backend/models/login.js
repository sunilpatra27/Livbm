const MongoClient = require('mongodb').MongoClient;
const URL = 'mongodb://localhost:27017';        // Connecton URL
const assert = require('assert');



module.exports.login = (loginDetails, callback) => {
    MongoClient.connect(URL, { useNewUrlParser: true },(err, client) => {
        assert.equal(null, err);
       
        let db = client.db(loginDetails.database);
        let collection = db.collection('user');
        collection.find({email:loginDetails.email}).toArray(callback);
        client.close();
        
    })
    }