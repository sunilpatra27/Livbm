import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, FormControl,Validators } from '@angular/forms';
import { Router } from '@angular/router';
import {LibService} from '../services/lib.service';
import { HttpErrorResponse} from '@angular/common/http';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  submitted = false;
  userDeatils:any={};
  



  constructor(private router: Router,private formBuilder: FormBuilder,private libService:LibService) { }

  ngOnInit() {

    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }
  get f() { return this.loginForm.controls; }
  
  
  
  login(){
    this.submitted = true;
    if(this.loginForm.valid){
      console.log(this.loginForm.controls);

      this.userDeatils.email=this.loginForm.controls.email.value;
      this.userDeatils.password=this.loginForm.controls.password.value;
      this.userDeatils.database="user_db";

      this.libService.login(JSON.stringify(this.userDeatils))
      .subscribe(data => {
            
console.log("listOfCompanies",data);

this.router.navigate(['home']);
          },

          (err: HttpErrorResponse) => {
if (err.status == 408) {
  //swal({ text: err.error, type: 'warning', confirmButtonText: 'Ok' })
    
} else if (err.status == 403) {
 // swal({ text: err.error, type: 'warning', confirmButtonText: 'Ok' })
    
} else{
//  swal({ text: 'Something Went Wrong.', type: 'warning', confirmButtonText: 'Ok' })
}
          });

  }
  else{
    
  }



   
   
  }

  signupRoute(){

    this.router.navigate(['register']);
  }

}
