const express = require('express');
const bodyParser= require('body-parser');
const app = express();
const cors = require('cors');

// Define All Routers needed to be linked
const route_user = require('./routes/user');
const route_login = require('./routes/login');

app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());
app.listen(3000, '10.18.80.234' ,function() {
  console.log('listening on 3000')
})
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader(
    'Access-Control-Allow-Headers',
    'Origin, X-Requested-With, Content-Type, Accept, Authorization'
  );
  next();
});
app.get('/', (req, res) => {
  res.send('inavlid request')
})
// Anything that has localhost:3000/*, route it to index.html
app.get('*', (req,res) => {
    res.sendFile(path.join(__dirname,'/public/index.html'));
})
// Anything that has localhost:3000/user, will be picked from user file
app.use('/user', route_user);
app.use('/login', route_login);


