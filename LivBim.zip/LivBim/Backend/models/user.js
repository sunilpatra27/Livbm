const MongoClient = require('mongodb').MongoClient;
const URL = 'mongodb://localhost:27017';        // Connecton URL
const assert = require('assert');
const uniqid = require('uniqid');
const moment = require('moment');



    module.exports.saveUser = (userDetails, callback) => {
    MongoClient.connect(URL, (err, client) => {
        assert.equal(null, err);
        console.log("Connected successfully to Mongo Server :", URL);
        console.log('Database need to be connected is ', userDetails.database);
        let db = client.db(userDetails.database);
        let collection = db.collection('user');
        collection.insert(userDetails,callback);
        client.close();
        console.log('Connection Closed in saveing user');
    })

  }

  module.exports.checkUserName = (userDetails, callback) => {
    MongoClient.connect(URL, (err, client) => {
        assert.equal(null, err);
        console.log("Connected successfully to Mongo Server :", URL);
        console.log('Database need to be connected is ', userDetails.database);
        let db = client.db(userDetails.database);
        let collection = db.collection('user');
        collection.findOne({userName:userDetails.userName},callback);
        client.close();
        console.log('Connection Closed in checking username ');
    })

  }
  module.exports.checkEmail = (userDetails, callback) => {
    MongoClient.connect(URL, (err, client) => {
        assert.equal(null, err);
        console.log("Connected successfully to Mongo Server :", URL);
        console.log('Database need to be connected is ', userDetails.database);
        let db = client.db(userDetails.database);
        let collection = db.collection('user');
        collection.findOne({email:userDetails.email},callback);
        client.close();
        console.log('Connection Closed in checking email ');
    })

  }

