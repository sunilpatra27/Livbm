import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class LibService {
  baseUrl="http://localhost:3000"

  constructor(private http: HttpClient) { }


  login(loginDetails) {
    let body = loginDetails;
    let headers = new HttpHeaders({ 'Content-Type': 'application/json; charset=utf-8' });
    return this.http.post(this.baseUrl + '/login/login', body, { headers });
  }

   signup(userDetails) {
    let body = userDetails;
    let headers = new HttpHeaders({ 'Content-Type': 'application/json; charset=utf-8' });
    return this.http.post(this.baseUrl + '/user/saveUser', body, { headers });
  }

  checkUserName(userDetails){
    let body = userDetails;
    let headers = new HttpHeaders({ 'Content-Type': 'application/json; charset=utf-8' });
    return this.http.post(this.baseUrl + '/user/checkUserName', body, { headers });

  }
  checkEmail(userDetails){
    let body = userDetails;
    let headers = new HttpHeaders({ 'Content-Type': 'application/json; charset=utf-8' });
    return this.http.post(this.baseUrl + '/user/checkEmail', body, { headers });

  }

}
